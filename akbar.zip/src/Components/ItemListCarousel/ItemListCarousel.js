import React, { useState, useEffect } from 'react';
import { items } from '../../DummyData/items';
import './ItemListCarousel.css';
import { Link } from 'react-router-dom';

const ItemListCarousel = (props) => {
    const [allItems, setAllItems] = useState([]);
    const [itemId, setItemId] = useState('');
    useEffect(() => {
        setAllItems(items);
        setItemId(props.id);

        const slider = document.querySelector('.drag_scroll');
	let mouseDown = false;
	let startX, scrollLeft;
	
	let startDragging = function (e) {
	  mouseDown = true;
	  startX = e.pageX - slider.offsetLeft;
	  scrollLeft = slider.scrollLeft;
	};
	let stopDragging = function (event) {
	  mouseDown = false;
	};
	
	slider.addEventListener('mousemove', (e) => {
	  e.preventDefault();
	  if(!mouseDown) { return; }
	  const x = e.pageX - slider.offsetLeft;
	  const scroll = x - startX;
	  slider.scrollLeft = scrollLeft - scroll;
	});
	
	// Add the event listeners
	slider.addEventListener('mousedown', startDragging, false);
	slider.addEventListener('mouseup', stopDragging, false);
	slider.addEventListener('mouseleave', stopDragging, false);

    });
    return (
        
                <div className="item-list-carousel drag_scroll">
                    

                    {
                        allItems.map(item => {
                            return(
                                <div className="single_item">
                                    <Link className="no_decoration" to={`/compare/`+ item.item_id}>
                                        <div className={itemId == item.item_id ? 'single-item-carousel active' : 'single-item-carousel'}>
                                            <div className="img_cont">
                                                <img className="prod_img" src={item.image_url} width="100" height="100"/>
                                            </div>
                                            <div>
                                                <div className="retail_cont_carousel">
                                                    <p>Price:</p>
                                                    <h3>{item.price}</h3>
                                                </div>
                                                <div className="gmv_cont_carousel">
                                                    <p>GMV:</p>
                                                    <h3>{item.gmv}</h3>
                                                </div>
                                            </div>
                                        </div>
                                    </Link>
                                </div>
                            )
                        })
                    }
                    
                </div>
            
    );
};

export default ItemListCarousel;
