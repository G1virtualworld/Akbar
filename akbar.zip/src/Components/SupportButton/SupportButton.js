import React from 'react';
import './SupportButton.css';



const SupportButton = ({onClick, ...props}) => {

  return (
    <>
        <a
            href={props.type="email" ? "mailto:"+props.email : props.type="phone" ? "tel:" + props.phone : '#'}
            className={"supportbutton " + props.position}
        >
            {props.children}
        </a>
        
    </>
    
  );
};


export default SupportButton;


