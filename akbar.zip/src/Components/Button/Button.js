import React from 'react';
import './Button.css';



const Button = ({onClick, ...props}) => {

  const handleButtonClick = (event) => {
    // const { onClick, disabled } = props;
  
    // if (disabled) return;
  
    onClick && onClick({ event });
  };

 
  return (
    <>
        <button
            className={`buttonfield ` + props.type}
            onClick={handleButtonClick}
            type="button"
        >
            {props.children}
        </button>
    </>
    
  );
};


export default Button;


