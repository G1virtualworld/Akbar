import React from 'react';
import './Checkbox.css';

const Checkbox = (props) => {
  return (
    <>
        <input type="checkbox" 
            id={props.id} 
            name={props.name} 
            value={props.value} 
            disabled={props.disabled}
            defaultChecked={props.checked}
        />
        <label htmlFor={props.id}> {props.children}</label>
    </>
    
  );
};


export default Checkbox;


