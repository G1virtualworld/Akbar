import React from 'react';
import './TextField.css';


const TextField = (props) => {
  return (
    <input type="text" className={`textfield ` + props.type} placeholder={props.placeholder} name={props.name}/>
    
  );
};


export default TextField;
