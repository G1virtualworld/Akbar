import React from 'react';
import './Radio.css';

const Radio = ({onChange, ...props}) => {
  const handleRadioChange = (event) => {
    // const { onClick, disabled } = props;
  
    if (props.disabled) return;
  
    onChange && onChange({ event });
  };
  return (
    <>
        <input type="radio" 
            id={props.id} 
            name={props.name} 
            value={props.value} 
            disabled={props.disabled}
            defaultChecked={props.checked}
            onClick={handleRadioChange}
        />
        <label htmlFor={props.id}> {props.children}</label>
    </>
    
  );
};


export default Radio;


