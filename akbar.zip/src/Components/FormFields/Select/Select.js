import React from 'react';
import './Select.css';


const Select = (props) => {
  return (
      <select className="selectfield" name={props.name} id={props.id} >
          {props.children}
      </select>
    
  );
};


export default Select;
