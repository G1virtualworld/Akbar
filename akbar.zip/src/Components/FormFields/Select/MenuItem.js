import React from 'react';


const MenuItem = (props) => {
  return (
    <option value={props.value}>{props.children}</option>
    
  );
};


export default MenuItem;


