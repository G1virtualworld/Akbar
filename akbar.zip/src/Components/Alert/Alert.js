import React, { useState } from 'react';
import './Alert.css';

const Alert = (props) => {

  const [isOpen, setIsOpen] = useState(true)

  return (
    <>
      {
      isOpen && 
        <div className={"alertfield " + props.type + ' ' + props.position}>
            <div>
              {props.children}
            </div>
            <div className="close-alert" onClick={() => setIsOpen(false)}>
                <i className="fa fa-times"></i>
            </div>
            
        </div>
      }
    </>
    
  );
};


export default Alert;


