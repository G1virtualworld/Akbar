import React, { useState, useEffect } from 'react';
import { items } from '../../DummyData/items';
import './Filters.css';

const Filters = () => {
    
    return (
        <div className="filters_cont">
            <div className="single_filter">
                <h4>Filter by</h4>
                <a href="#"className='btn'>RESET</a>
                <a href="#"className='btn'>APPLY</a>
            </div>
            
            <div className="separator"></div>
            
            <div className="Candidate_Source">
                <h4> Candidate Source</h4>
                <div className="checkbox">
                <input type="checkbox"/>walmart
                <input type="checkbox"/> Non walmart
                </div>
            </div>
            <div className="separator"></div>
            <div className="Candidate_Availabilty">
                <h4> Candidate Availabilty</h4>
                <div className="checkbox">
                <input type="checkbox"/>Available
                <input type="checkbox"/> Not Available
                </div>
            </div>
            <div className="separator"></div>

            <h4> Competetors</h4>
            <div className="Competetors">
                
                <div className="checkbox">
                <input type="checkbox"/>homedepot.ca<br></br>
                <input type="checkbox"/> voila.ca<br></br>
                <input type="checkbox"/>amazon.ca<br></br>
                <input type="checkbox"/>bestbuy.ca<br></br>
                <input type="checkbox"/>toysrus.ca<br></br>
                </div>
            </div>

            <div className="separator"></div>

            <div className="Offer_Type">
                <h4> Offer Type</h4>
                <div className="checkbox">
                <input type="checkbox"/>1P
                <input type="checkbox"/> 3P
                </div>
            </div>

            <div className="separator"></div>
               
                <div className="Filter_By">
                    <h4>Filter By</h4>
                    <a href="#" class="fltr-button">Review</a>
                </div>

            <div className="separator"></div>
           
                <div className="Sort_By">
                    <h4>Sort By</h4>
                    <a href="#" class="fltr-button">GMV</a>
                    <a href="#" class="fltr-button">RETAIL PRICE</a>
                    
                </div>
        </div>
    );
};

export default Filters;
