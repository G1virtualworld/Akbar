import React from 'react';
import './Table.css';


const TableRow = (props) => {
  return (
      <tr className="tablerow">
        {props.children}
      </tr>
    
  );
};


export default TableRow;
