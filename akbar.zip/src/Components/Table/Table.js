import React from 'react';
import './Table.css';


const Table = (props) => {
  return (
      <table className={"tablefield " + props.variant}>
        {props.children}
      </table>
    
  );
};


export default Table;
