import React from 'react';
import './Table.css';


const TableColumn = (props) => {
  return (
      <th className="tablecolumn">
        {props.children}
      </th>
    
  );
};


export default TableColumn;
