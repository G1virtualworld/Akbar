import React from 'react';
import './Table.css';


const TableColumn = (props) => {
  return (
      <td className="tablecolumn">
        {props.children}
      </td>
    
  );
};


export default TableColumn;
