import React from 'react';
import './Table.css';


const TableHead = (props) => {
  return (
      <thead className="tablehead">
        {props.children}
      </thead>
    
  );
};


export default TableHead;
