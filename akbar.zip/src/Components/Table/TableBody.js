import React from 'react';
import './Table.css';


const TableBody = (props) => {
  return (
      <tbody className="tablebody">
        {props.children}
      </tbody>
    
  );
};


export default TableBody;
