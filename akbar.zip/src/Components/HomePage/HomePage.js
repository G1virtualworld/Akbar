import React, { useState, useEffect } from 'react';
import './HomePage.css';
import TextField from '../FormFields/TextField/TextField';
import Select from '../FormFields/Select/Select';
import MenuItem from '../FormFields/Select/MenuItem';
import Checkbox from '../FormFields/Checkbox/Checkbox';
import Radio from '../FormFields/Radio/Radio';
import Button from '../Button/Button';
import Accordion from '../Accordion/Accordion';
import AccordionItem from '../Accordion/AccordionItem';
import Alert from '../Alert/Alert';

import Table from '../Table/Table';
import TableBody from '../Table/TableBody';
import TableColumn from '../Table/TableColumn';
import TableHead from '../Table/TableHead';
import TableRow from '../Table/TableRow';
import TableColumnHead from '../Table/TableColumnHead';

import SupportButton from '../SupportButton/SupportButton';

import Main from '../HorizentalStepper/Main'


const HomePage = (props) => {
  
  
  
  const [isSuccessAlert, setIsSuccessAlert] = useState(false);
  const [isDangerAlert, setIsDangerAlert] = useState(false);
  const [isNormalAlert, setIsNormalAlert] = useState(false);

  const [supportButtonVisible, setSupportButtonVisible] = useState(false);
  const [supportButtonType, setSupportButtonType] = useState('email');
  const [supportButtonEmail, setSupportButtonEmail] = useState('hello@test.com');
  const [supportButtonPhone, setSupportButtonPhone] = useState('1234567890');
  const [supportButtonPosition, setSupportButtonPosition] = useState('bottom-right');

  function showSupportButton(e) {
	e.preventDefault();
	setSupportButtonEmail(e.target[2].value);
	setSupportButtonPhone(e.target[2].value);
	setSupportButtonVisible(true);
	console.log(e)
  }
  useEffect(() => {
    

  });
  return (
    <section className="container">

		
		
		<div className="single-section text-field">
			<h1 className="title">TextField</h1>
			<div className="single-element">
				<h4>Box type</h4>
				
				<code className="code-block">
					{`<TextField type="box" placeholder="Type your text" name="box"/>`}
				</code>
				<h4>Output</h4>
				<TextField type="box" placeholder="Type your text" name="box"/>
			</div>
			<div className="single-element">
				<h4>Standard type</h4>
				
				<code className="code-block">
					{`<TextField type="standard" placeholder="Type your text" name="standard"/>`}
				</code>
				<h4>Output</h4>
				<TextField type="standard" placeholder="Type your text" name="standard"/>
			</div>
		</div>
		<hr/>
		<div className="single-section select-field">
			<h1 className="title">Select Field</h1>
			<div className="single-element">
				
				<code className="code-block">
					{`<Select name="test" id="test">
	<MenuItem value="one">Option 1</MenuItem>
	<MenuItem value="two">Option 2</MenuItem>
</Select>`}
				</code>

				<h4>Output</h4>
				<Select name="test" id="test">
					<MenuItem value="one">Option 1</MenuItem>
					<MenuItem value="two">Option 2</MenuItem>
				</Select>
			</div>
			
		</div>
		<hr/>
		<div className="single-section checkbox-field">
			<h1 className="title">Checkbox</h1>
			<div className="single-element">
				
				<code className="code-block">
					{`<Checkbox id="disabled" name="disabled" disabled>Disabled</Checkbox>
<Checkbox id="normal" name="normal">Normal</Checkbox>
<Checkbox id="checked" name="checked" checked>Checked</Checkbox>`}
				</code>

				<h4>Output</h4>
				<Checkbox id="disabled" name="disabled" disabled>Disabled</Checkbox>
				<Checkbox id="normal" name="normal">Normal</Checkbox>
				<Checkbox id="checked" name="checked" checked>Checked</Checkbox>
			</div>
			
		</div>
		<hr/>
		<div className="single-section radio-field">
			<h1 className="title">Radio Buttons</h1>
			<div className="single-element">
				
				<code className="code-block">
					{`<Radio id="radio1" name="gender" value="male">Male</Radio>
<Radio id="radio2" name="gender" value="female">Female</Radio>
<Radio id="radio3" name="gender" value="third" disabled>Third</Radio>`}
				</code>

				<h4>Output</h4>
				<Radio id="radio1" name="gender" value="male" checked onChange={() => console.log('changed')}>Male</Radio>
				<Radio id="radio2" name="gender" value="female" onChange={() => console.log('changed')}>Female</Radio>
				<Radio id="radio3" name="gender" value="third" disabled onChange={() => console.log('changed')}>Third</Radio>
			</div>
			
		</div>
		<hr/>
		<div className="single-section button-field">
			<h1 className="title">Button Component</h1>
			<div className="single-element">
				
				<code className="code-block">
					{`<Button type="filled">Click Me</Button>`}
				</code>

				<h4>Output</h4>
				<Button type="filled">Click Me</Button>
			</div>
			
		</div>
		<hr/>




		
<div className="single-section button-field">
			<h1 className="title">HorizentalStepper</h1>
			<div className="single-element">
				
				<code className="code-block">

                {`<button className="Next" onClick={this.continue}>
                Next »
                </button>
                <button className="Back" onClick={this.back}>
                « Back
	            </button>
	            <button className="Next" onClick={this.continue}>
                Next »
	            </button>
	            <h2>Here is the information you entered:</h2>
                First Name: <b>{firstName}</b><br />
                Last Name: <b>{lastName}</b><br />
                Job: <b>{jobTitle}</b><br />
                Company: <b>{jobCompany}</b><br />
                Location: <b>{jobLocation}</b><br />
                <button className="Back" onClick={this.back}>
                    « Back
                </button>
                   `}
				</code>
				<h4>Output</h4>
				<Main></Main>
				

			</div>
			
		</div>
		











		<div className="single-section accordion-field">
			<h1 className="title">Accordion</h1>
			<div className="single-element">
				
				<code className="code-block">
					{`<Accordion>
	<AccordionItem
		title="title of the accordion"
		content="Content of the accordion"
	>
	</AccordionItem>	
	<AccordionItem
		title="Second title of the accordion"
		content="Second Content of the accordion"
	>
	</AccordionItem>
</Accordion>`}
				</code>

				<h4>Output</h4>
				<Accordion>
					<AccordionItem
						title="title of the accordion"
						content="Content of the accordion"
					>
					</AccordionItem>	
					<AccordionItem
						title="Second title of the accordion"
						content="Second Content of the accordion"
					>
					</AccordionItem>
				</Accordion>
			</div>
			
		</div>
		<hr/>
		<div className="single-section alert-field">
			<h1 className="title">Alert</h1>
			<div className="single-element">
				
				<code className="code-block">
					{`//Success
<Alert type="success" position="bottom-left">
	This is the success alert
</Alert>

//Danger
<Alert type="danger" position="bottom-right">
	This is the danger alert
</Alert>

//Normal
<Alert type="normal" position="top-right">
	This is the nortmal alert
</Alert>`}
				</code>

				<h4>Output</h4>
				<Button type="filled" onClick={() => setIsSuccessAlert(!isSuccessAlert)}>Open Success Alert</Button>
				<Button type="filled" onClick={() => setIsDangerAlert(!isDangerAlert)}>Open Danger Alert</Button>
				<Button type="filled" onClick={() => setIsNormalAlert(!isNormalAlert)}>Open Normal Alert</Button>
				{
					isSuccessAlert &&
					<Alert type="success" position="bottom-left">
						This is the success alert
					</Alert>
				}
				{
					isDangerAlert &&
					<Alert type="danger" position="bottom-right">
						This is the danger alert
					</Alert>
				}

				{
					isNormalAlert &&
					<Alert type="normal" position="top-right">
						This is the nortmal alert
					</Alert>
				}
			</div>
            
			
		</div>
		<hr/>
		<div className="single-section table-field">
			<h1 className="title">Table Component</h1>
			<div className="single-element">
				<h3>Striped</h3>
				<code className="code-block">
					{`<Table variant="striped">
				
	<TableRow>
		<TableColumnHead>Sr No.</TableColumnHead>
		<TableColumnHead>Name</TableColumnHead>
		<TableColumnHead>Email</TableColumnHead>
		<TableColumnHead>Address</TableColumnHead>
	</TableRow>

	<TableRow>
		<TableColumn>1</TableColumn>
		<TableColumn>My Name</TableColumn>
		<TableColumn>hello@test.com</TableColumn>
		<TableColumn>Test Address</TableColumn>
	</TableRow>

	<TableRow>
		<TableColumn>2</TableColumn>
		<TableColumn>Your Name</TableColumn>
		<TableColumn>hi@testing.com</TableColumn>
		<TableColumn>Test Address 2</TableColumn>
	</TableRow>

	<TableRow>
		<TableColumn>3</TableColumn>
		<TableColumn>Test Name</TableColumn>
		<TableColumn>hola@testing.com</TableColumn>
		<TableColumn>Test Address 3</TableColumn>
	</TableRow>
	
</Table>`}
				</code>

				<h4>Output</h4>
				<Table variant="striped">
				
						<TableRow>
							<TableColumnHead>Sr No.</TableColumnHead>
							<TableColumnHead>Name</TableColumnHead>
							<TableColumnHead>Email</TableColumnHead>
							<TableColumnHead>Address</TableColumnHead>
						</TableRow>
					
					
						<TableRow>
							<TableColumn>1</TableColumn>
							<TableColumn>My Name</TableColumn>
							<TableColumn>hello@test.com</TableColumn>
							<TableColumn>Test Address</TableColumn>
						</TableRow>
						<TableRow>
							<TableColumn>2</TableColumn>
							<TableColumn>Your Name</TableColumn>
							<TableColumn>hi@testing.com</TableColumn>
							<TableColumn>Test Address 2</TableColumn>
						</TableRow>
						<TableRow>
							<TableColumn>3</TableColumn>
							<TableColumn>Test Name</TableColumn>
							<TableColumn>hola@testing.com</TableColumn>
							<TableColumn>Test Address 3</TableColumn>
						</TableRow>
					
				</Table>
			</div>
			
			<div className="single-element">
				<h3>Bordered</h3>
				<code className="code-block">
					{`<Table variant="bordered">
				
	<TableRow>
		<TableColumnHead>Sr No.</TableColumnHead>
		<TableColumnHead>Name</TableColumnHead>
		<TableColumnHead>Email</TableColumnHead>
		<TableColumnHead>Address</TableColumnHead>
	</TableRow>

	<TableRow>
		<TableColumn>1</TableColumn>
		<TableColumn>My Name</TableColumn>
		<TableColumn>hello@test.com</TableColumn>
		<TableColumn>Test Address</TableColumn>
	</TableRow>

	<TableRow>
		<TableColumn>2</TableColumn>
		<TableColumn>Your Name</TableColumn>
		<TableColumn>hi@testing.com</TableColumn>
		<TableColumn>Test Address 2</TableColumn>
	</TableRow>
	
	<TableRow>
		<TableColumn>3</TableColumn>
		<TableColumn>Test Name</TableColumn>
		<TableColumn>hola@testing.com</TableColumn>
		<TableColumn>Test Address 3</TableColumn>
	</TableRow>
	
</Table>`}
				</code>

				<h4>Output</h4>
				<Table variant="bordered">
				
					<TableRow>
						<TableColumnHead>Sr No.</TableColumnHead>
						<TableColumnHead>Name</TableColumnHead>
						<TableColumnHead>Email</TableColumnHead>
						<TableColumnHead>Address</TableColumnHead>
					</TableRow>

					<TableRow>
						<TableColumn>1</TableColumn>
						<TableColumn>My Name</TableColumn>
						<TableColumn>hello@test.com</TableColumn>
						<TableColumn>Test Address</TableColumn>
					</TableRow>

					<TableRow>
						<TableColumn>2</TableColumn>
						<TableColumn>Your Name</TableColumn>
						<TableColumn>hi@testing.com</TableColumn>
						<TableColumn>Test Address 2</TableColumn>
					</TableRow>
					
					<TableRow>
						<TableColumn>3</TableColumn>
						<TableColumn>Test Name</TableColumn>
						<TableColumn>hola@testing.com</TableColumn>
						<TableColumn>Test Address 3</TableColumn>
					</TableRow>
					
				</Table>
			</div>
			

			
			
		</div>

		<hr/>
		<div className="single-section support-button-field">
			<h1 className="title">Support Button Component</h1>

			<div className="single-element">
				
				<code className="code-block">
					{`<SupportButton type="email email="hello@test.com position="bottom-right">
	<i className="fa fa-support"></i>
</SupportButton>`}
				</code>

				<h4>Output</h4>
				<form onSubmit={(e) => showSupportButton(e)} >
				<div>
					<h4>Select Support Type</h4>
					<Radio id="supportemail" name="supporttype" value="email" onChange={(e) => {setSupportButtonType('email')}}>Email</Radio>
					<Radio id="supportphone" name="supporttype" value="phone" onChange={(e) => {setSupportButtonType('phone')}}>Phone</Radio>
				</div>
				<div>
					{
						supportButtonType == 'email' ?
						<>
							<h4>Your Email Address</h4>
							<TextField placeholder="Enter your email address" name="email_address" type="box"/>
						</>
						:
						<>
							<h4>Your Phone Number</h4>
							<TextField placeholder="Enter your phone number" name="phone_number" type="box"/>
						</>
					}
				</div>
				<div>
					<h4>Select Support Button Position</h4>
					<Radio name="supportposition" value="bottomleft" onChange={(e) => {setSupportButtonPosition('bottom-left')}}>Bottom Left</Radio>
					<Radio name="supportposition" value="bottomright" onChange={(e) => {setSupportButtonPosition('bottom-right')}}>Bottom Right</Radio>
				</div>
				<div style={{margin:'20px 0px'}}>
					<input type="submit" className="buttonfield filled" value="Show Support Button"/>
				</div>
				<div>
				{
					supportButtonVisible &&
					<Button type="filled" onClick={() => setSupportButtonVisible(false)}>Hide Support Button</Button>
				}
					
				</div>
			</form>
			{
				supportButtonVisible &&
				<SupportButton type={supportButtonType} email={supportButtonEmail} phone={supportButtonPhone} position={supportButtonPosition}>
					<i className="fa fa-support"></i>
				</SupportButton>
			}
			</div>
			
			
		</div>

	</section> 


  );
};

export default HomePage;

