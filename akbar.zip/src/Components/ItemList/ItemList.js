import React, { useState, useEffect } from 'react';
import { items } from '../../DummyData/items';
import './ItemList.css';
import Filters from '../Filters/Filters';
import { Link, NavLink } from 'react-router-dom';
import Breadcrumb from '../Breadcrumb/Breadcrumb';


const ItemList = () => {
    const [allItems, setAllItems] = useState([]);
    useEffect(() => {
        setAllItems(items)
    });
    return (
        <div className="container">
            <h1>Item List Page</h1>
            <Breadcrumb />
            <div className="with-filters">
                <div className="filters_main">
                    <Filters />
                </div>
                <div className="item-list-page">
                    {
                        allItems.map(item => {
                            return(
                                <Link className="no_decoration" to={`/compare/`+ item.item_id}>
                                    <div className="single-item">
                                        <div className="img_title_cont">
                                            <img className="prod_img" src={item.image_url} width="100" height="100"/>
                                            <p className="item_id">Walmart #{item.item_id}</p>
                                            <h3 className="item_title">{item.title}</h3>
                                        </div>
                                        <div className="retail_cont">
                                            <p>Retail Price</p>
                                            <h3>{item.price}</h3>
                                        </div>
                                        <div className="separator"></div>
                                        <div className="gmv_cont">
                                            <p>GMV</p>
                                            <h3>{item.gmv}</h3>
                                        </div>
                                        <div className="button_cont">
                                            <a href="" className="button">{item.candidates_count} Candidates</a>
                                        </div>
                                        
                                    </div>
                                </Link>
                            )
                        })
                    }
                </div>
            </div>
        </div>
    );
};

export default ItemList;
