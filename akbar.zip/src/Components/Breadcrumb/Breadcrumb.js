import React from 'react';
import './Breadcrumb.css';
import { Route, Switch } from 'react-router';
import { Link, BrowserRouter } from 'react-router-dom';


const Breadcrumb = (props) => {
  return (
    <div className="breadcrumbs">
        <i class="fa fa-arrow-circle-o-left"></i>
        <ul className=''>
            
            <Route 
                path='/' 
                render={props => (
                    <BreadcrumbsItem {...props} title="Item List Page" />
                )}
            />
            <Route 
                path='/compare/:id' 
                render={props => (
                    <BreadcrumbsItem {...props} title="Compare Page" />
                )}
            />
        </ul>
    </div>
  );
};

const BreadcrumbsItem = ({ match, ...rest }) => (
    
    <React.Fragment>
        {console.log('match', match, rest)}
        <li className={match.isExact ? 'breadcrumb-active' : undefined}>
            {
                match.isExact ?
                    rest.title
                :
                <Link to={match.url || ''}>
                    {rest.title}
                </Link>
            }
            {/* <Link to={match.url || ''}>
                {rest.title}
            </Link> */}
        </li>
    </React.Fragment>
)

export default Breadcrumb;
